// CONFIGURACIÓN DE CONEXIÓN AL SERVIDOR LOCAL
// Usando Node.js + SQLite (backend local)

const API_BASE_URL = 'http://localhost:3000/api';

console.log('API Base URL:', API_BASE_URL);
